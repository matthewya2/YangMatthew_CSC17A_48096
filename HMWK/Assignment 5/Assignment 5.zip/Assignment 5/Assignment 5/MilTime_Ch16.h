/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   MilTime.h
 * Author: Matthew
 *
 * Created on December 4, 2016, 10:50 PM
 */

#ifndef MILTIME_H
#define MILTIME_H

class Time2
{   
protected:
    int hou;
    int mi;
    int se;
public:
    Time2()
        {hou = 0; mi = 0;}
    Time2(int h, int m, int s)
        {hou = h; mi = m;}
    int getHr2() const
        {return hou;}
    int getMin2() const
        {return mi;}
};

class MilTime2 : public Time2{
    private:
        int milHour;
        int milSecond;
    public:
        MilTime2(){
            milHour=0;
            milSecond=0;
        }
        bool setTime2(int,int);
        int getHour2()const{
            return milHour;}
        int getStandHr2()const{
            return hou;}

};


#endif /* MILTIME_H */

