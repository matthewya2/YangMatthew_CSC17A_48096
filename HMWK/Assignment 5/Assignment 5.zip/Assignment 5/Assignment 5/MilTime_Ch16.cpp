/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   MilTime.cpp
 * Author: Matthew
 *
 * Created on December 4, 2016, 11:06 PM
 */

#include <cstdlib>
#include <string>
#include  "MilTime_Ch16.h"
using namespace std;

bool MilTime2::setTime2(int miltime2,int seconds2){    
    bool pm=false;   
    milHour=miltime2;
    milSecond=seconds2;
    
    mi=miltime2%100;        
    miltime2-=mi;            
    hou=miltime2/100;
    se=seconds2;
    if (se>59){
        string BadSeconds="Invalid second Value.";
        throw(BadSeconds);
    }
    
    if (milHour>2359){
        string BadHour="Invalid Hour Value.";
        throw(BadHour);
    }
    
    if (hou>11){
        pm=true;
        if(hou>12){hou-=12;}
        return pm;
    }
    return pm;
}