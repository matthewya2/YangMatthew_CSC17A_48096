/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Matthew
 *
 * Created on December 5, 2016, 9:58 PM
 */
//Library includes Here!!!
#include <iostream>
#include <cstdlib>
#include "Date.h"
#include "MilTime.h"
#include "MilTime_Ch16.h"
#include "employee.h"
using namespace std;

//Global Constants Here!!!
//Function Prototypes Here!!!
void Menu();
int getN();
void def(int);
void problem1();
void problem2();
void problem3();
void problem4();
void problem5();

//Begin Execution Here!!!
int main(int argv,char *argc[]){
    int inN;
    do{
        Menu();
        inN=getN();
        switch(inN){
        case 1:    problem1();break;
        case 2:    problem2();break;
        case 3:    problem3();break;
        case 4:    problem4();break;
        case 5:    problem5();break;
        default:   def(inN);}
    }while(inN>=1&&inN<=5);
    return 0;
}

void Menu(){
    cout<<"Menu for the Midterm"<<endl;
    cout<<"Type 1 for Employee and ProductionWorker classes"<<endl;
    cout<<"Type 2 for ShiftSupervisor class"<<endl;
    cout<<"Type 3 for Time Format"<<endl;
    cout<<"Type 4 for Date Exceptions"<<endl;
    cout<<"Type 5 for Time Format Exceptions"<<endl;
    cout<<"Type anything else to exit \n"<<endl;
}

int getN(){
        int inN;
        cin>>inN;
        return inN;
}

void problem1(){
        cout<<"In problem # 1"<<endl<<endl;
    string name, num, date;
    int shift;
    float pay;
    
    
    cout<<"Enter name:"<<endl;
    cin>>name;
    cout<<"Enter number:"<<endl;
    cin>>num;
    cout<<"Enter date:"<<endl;
    cin>>date;
    cout<<"Enter 1 for day shift and 2 for night shift:"<<endl;
    cin>>shift;
    cout<<"Enter Hourly Pay:"<<endl;
    cin>>pay;
    
    try{
        ProductionWorker info (shift);
        info.setName(name);
        info.setNum(num);
        info.setDate(date);
        info.setShift(shift);
        info.setPayRate(pay);
        
        cout<<"Name: "<<info.getName()<<endl;
        cout<<"Date: "<<info.getDate()<<endl;
        cout<<"Number: "<<info.getNumber()<<endl;
        if(info.getShift()==1){
            cout <<"DayShift,"<<endl;
        }
        else{
            cout <<"NightShift,"<<endl;
        }
        cout<<"Hourly Pay: "<<info.getPayRate()<<endl;
    }
    catch(string shiftEr){
        cout <<"Error: "<< shiftEr;
    }
}

void problem2(){
        cout<<"In problem # 2"<<endl<<endl;
    float goal,bone,work,sal;   //goal/bonus/current money/salary
    float totSal;               //total salary
    int null=1;                 //void
    cout << "what is your production goal?"<<endl;
    cin >> goal;
    cout << "what is your bonus if you accomplish that salary goal?"<<endl;
    cin >> bone;
    cout <<"how much have you actually accomplished, money-wise?"<<endl;
    cin >> work;
    cout << "how much is your normal salary?"<<endl;
    cin>> sal;
    
    ShiftSupervisor SS(null);
    
    if (goal<=work){    SS.setSalary(bone,sal);}
    else{   SS.setSalary(sal);}
    totSal=SS.getSalary();
    cout <<"you have made, $"<<totSal<<endl;
}

void problem3(){
        cout<<"In problem # 3"<<endl<<endl;
    int milTime,milHour,milSec;
    int standH, standM;
    bool pm;
    
    cout <<"what time is it,(hours) in Military time?"<<endl;
    cin>>milTime;
    while((milTime%100)>59){
        cout <<"please enter a valid minute(MM) value, (HHMM format, "
                "whereas MM cannot be more than 59)"<<endl;
        cin >>milTime;
    }
    while(milTime>2359){
        cout <<"please enter a valid military time value, it cannot be over 2359"
                <<endl;
        cin >>milTime;
    }
    
    cout <<"how many seconds?"<<endl;
    cin>>milSec;
    while((milSec)>59){
        cout <<"please enter a valid second value, whereas seconds cannot"
                " be more than 59"<<endl;
        cin >>milSec;
    }
    
    MilTime mTime;
    pm=mTime.setTime(milTime,milSec);
    
    standH=mTime.getHr();
    standM=mTime.getMin();
    milHour=mTime.getHour();
    
    //output standard time
    cout <<"standard time is: "<< standH<<":"<<standM<<", and "<<milSec<<" seconds, ";
    if (pm==true){
        cout <<"P.M."<<endl;
    }
    else{cout <<"A.M."<<endl;}
    
    cout <<"Military time is: "<<milHour<<", and "<<milSec<<" seconds, ";
    if (pm==true){
        cout <<"P.M."<<endl;
    }
    else{cout <<"A.M."<<endl;}
}

void problem4(){
        cout<<"In problem # 4"<<endl<<endl;
    Date date;
    int temp;
    
    cout << "what is the date? "<<endl;
    cout << "input the year first. (yyyy)"<<endl;
    cin  >> temp;
    date.setYear(temp);
    
    try{
        cout << "Now input the month. (mm)"<<endl;
        cin  >> temp;
        date.setMonth(temp);

        cout << "now input the day.(dd)"<<endl;
        cin  >> temp;
        date.setDay(temp);
    }
    catch(string err){
        cout <<"error: "<<err<<endl;
        exit;
    }
    
    date.print1();
    date.print2();
    date.print3();
}

void problem5(){
        cout<<"In problem # 5"<<endl<<endl;
        cout <<"i had trouble on lines 226. I was able to do the problem in a"
                " seperate program, but i could not figure out why"<<endl<<
                " netbeans kept saying, error: 'm' was not declared"
                " in this scope, while i tried to put it into a menu. "<<endl;
        cout <<"i will attach the program seperately to prove that i was able"
                " to do the problem, it was just trouble putting it into a menu."
                <<endl<<endl;
//    int milTime,milHour,milSec;
//    int standH, standM;
//    bool pm;
//    
//    cout <<"what time is it,(hours) in Military time?"<<endl;
//    cin>>milTime;
//    
//    cout <<"how many seconds?"<<endl;
//    cin>>milSec;
//    
//    MilTime2 m;         //keeps saying error: 'm' was not declared in this scope
//    try{                //input validation
//        pm=m.setTime2(milTime,milSec);
//    }
//    catch(string err){
//        cout << "Error: "<<err<<endl;
//        exit;
//    }
//    
//    standH=m.getHr2();
//    standM=m.getMin2();
//    milHour=m.getHour2();
//    
//    //output standard time
//    cout <<"standard time is: "<< standH<<":"<<standM<<", and "<<milSec<<" seconds, ";
//    if (pm==true){
//        cout <<"P.M."<<endl;
//    }
//    else{cout <<"A.M."<<endl;}
//    
//    cout <<"Military time is: "<<milHour<<", and "<<milSec<<" seconds, ";
//    if (pm==true){
//        cout <<"P.M."<<endl;
//    }
//    else{cout <<"A.M."<<endl;}
}



void def(int inN){
        cout<<"You typed "<<inN<<" to exit the program"<<endl;
}